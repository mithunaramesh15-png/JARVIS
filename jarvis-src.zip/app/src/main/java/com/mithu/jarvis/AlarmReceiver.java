package com.mithu.jarvis;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

/** Shows a reminder when its time comes, then sets the next one. */
public class AlarmReceiver extends BroadcastReceiver {

    static final String ADD_WATER = "com.mithu.jarvis.ADD_WATER";
    static final String NUTS_DONE = "com.mithu.jarvis.NUTS_DONE";
    static final String ITEM_DONE = "com.mithu.jarvis.ITEM_DONE";

    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction() == null ? "" : intent.getAction();
        NotificationManager nm = c.getSystemService(NotificationManager.class);

        if (ADD_WATER.equals(action) || NUTS_DONE.equals(action)) {
            try {
                JSONObject s = Scheduler.state(c);
                String key = ADD_WATER.equals(action) ? "water" : "nutsLog";
                JSONObject log = s.optJSONObject(key);
                if (log == null) { log = new JSONObject(); s.put(key, log); }
                String d = Scheduler.today();
                if (ADD_WATER.equals(action)) log.put(d, log.optInt(d, 0) + 1);
                else log.put(d, true);
                Scheduler.saveState(c, s);
            } catch (Exception ignored) { }
            nm.cancel(ADD_WATER.equals(action) ? Scheduler.WATER : Scheduler.NUTS);
            return;
        }

        if (ITEM_DONE.equals(action)) {
            String id = intent.getStringExtra("task");
            try {
                JSONObject s = Scheduler.state(c);
                for (String list : new String[]{"tasks", "alarms"}) {
                    JSONArray arr = s.optJSONArray(list);
                    if (arr != null && id != null) for (int i = 0; i < arr.length(); i++) {
                        JSONObject t = arr.optJSONObject(i);
                        if (t != null && id.equals(t.optString("id"))) {
                            t.put("done", true);
                            t.put("doneAt", System.currentTimeMillis());
                        }
                    }
                }
                Scheduler.saveState(c, s);
            } catch (Exception ignored) { }
            nm.cancel(intent.getIntExtra("code", 0));
            Scheduler.scheduleAll(c);
            return;
        }

        String kind = intent.getStringExtra("kind");
        int code = intent.getIntExtra("code", 0);
        if (kind == null) kind = "";
        try {
            show(c, nm, kind, code, intent.getStringExtra("task"));
        } catch (Exception ignored) { }

        if ("focus".equals(kind)) {
            try {
                JSONObject s = Scheduler.state(c);
                s.put("focusEnd", 0);
                JSONObject done = s.optJSONObject("focusDone");
                if (done == null) { done = new JSONObject(); s.put("focusDone", done); }
                String d = Scheduler.today();
                done.put(d, done.optInt(d, 0) + 1);
                Scheduler.saveState(c, s);
            } catch (Exception ignored) { }
        }
        Scheduler.scheduleAll(c);
    }

    private PendingIntent broadcast(Context c, String action, int req, String id, int code) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(action);
        if (id != null) i.putExtra("task", id);
        i.putExtra("code", code);
        return PendingIntent.getBroadcast(c, req, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void show(Context c, NotificationManager nm, String kind, int code, String id) throws Exception {
        JSONObject s = Scheduler.state(c);
        String title = null, text = null;
        Notification.Action action = null;
        String today = Scheduler.today();

        switch (kind) {
            case "water": {
                JSONObject w = Scheduler.settings(s, "water");
                int goal = w.optInt("goal", 8);
                JSONObject log = s.optJSONObject("water");
                int had = log == null ? 0 : log.optInt(today, 0);
                if (had >= goal) return;
                title = "Water time";
                text = "Drink one glass of water now. Today: " + had + " of " + goal + " glasses.";
                action = new Notification.Action.Builder(null, "I drank 1 glass",
                        broadcast(c, ADD_WATER, 90001, null, 0)).build();
                break;
            }
            case "sleep": {
                JSONObject sl = Scheduler.settings(s, "sleep");
                title = "Time to wind down";
                text = "Bedtime is " + sl.optString("bed", "22:30") + ". Finish up, put the phone away, and sleep so you wake fresh at "
                        + sl.optString("wake", "06:30") + ".";
                break;
            }
            case "kitchen": {
                List<String> soon = Scheduler.expiringSoon(s);
                if (soon.isEmpty()) return;
                title = "Use these soon";
                text = String.join(", ", soon) + ". Open Jarvis to see recipes that use them.";
                break;
            }
            case "cook": {
                JSONObject out = s.optJSONObject("out");
                JSONObject od = out == null ? null : out.optJSONObject(today);
                if (od != null && od.optBoolean("d")) return; // not cooking dinner today
                List<String> soon = Scheduler.expiringSoon(s);
                double kg = Scheduler.latestWeight(s);
                JSONObject prof = s.optJSONObject("profile");
                double ppk = prof == null ? 1.2 : prof.optDouble("ppk", 1.2);
                double left = kg * ppk - Scheduler.proteinToday(s);
                StringBuilder b = new StringBuilder();
                if (!soon.isEmpty()) b.append("Use your ").append(soon.get(0).replaceAll(" \\(.*\\)$", "")).append(" before it spoils. ");
                if (kg > 0 && left > 5) b.append(String.format(Locale.US, "You still need about %.0f g protein today. ", left));
                b.append("Home food is cheaper and better for you. Tap for instant recipe ideas.");
                title = "Cook at home tonight";
                text = b.toString();
                break;
            }
            case "weigh":
                title = "Weigh-in day";
                text = "Weigh yourself before breakfast and add it in Jarvis (Me tab).";
                break;
            case "focus":
                title = "Focus session done";
                text = "Great work. Stand up, drink some water, and take a 5-minute break.";
                break;
            case "nuts": {
                JSONObject log = s.optJSONObject("nutsLog");
                if (log != null && log.optBoolean(today)) return;
                JSONObject n = Scheduler.settings(s, "nuts");
                title = "Nuts & seeds time";
                text = "Have your daily handful: " + n.optString("what", "5 almonds, 2 walnuts, 1 tbsp seeds") + ".";
                action = new Notification.Action.Builder(null, "Done",
                        broadcast(c, NUTS_DONE, 90002, null, 0)).build();
                break;
            }
            case "nutsoak": {
                JSONObject n = Scheduler.settings(s, "nuts");
                title = "Soak your almonds";
                text = "Soak tomorrow's almonds in water now: " + n.optString("what", "5 almonds") + ".";
                break;
            }
            case "grocery": {
                List<String> g = Scheduler.groceryList(s);
                title = "Grocery day";
                text = g.isEmpty() ? "Your list is empty. Check your kitchen in Jarvis before you go."
                        : "To buy (" + g.size() + "): " + String.join(", ", g) + ".";
                break;
            }
            case "weekly": {
                List<String> p = Scheduler.weeklyPending(s);
                if (p.isEmpty()) return;
                int dl = Scheduler.daysLeftInWeek();
                title = p.size() + " weekly task" + (p.size() > 1 ? "s" : "") + " left";
                text = String.join(", ", p) + ". " + dl + " day" + (dl > 1 ? "s" : "") + " left this week. Pick one and start small.";
                break;
            }
            case "task":
            case "alarm": {
                JSONArray arr = s.optJSONArray(kind.equals("task") ? "tasks" : "alarms");
                if (arr != null && id != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject t = arr.optJSONObject(i);
                    if (t != null && id.equals(t.optString("id"))) {
                        if (t.optBoolean("done")) return;
                        title = t.optString("t", "Reminder");
                        text = t.optString("note", kind.equals("task") ? "It's time for this task. Small steps add up." : "");
                    }
                }
                if (title == null) return;
                if (text.isEmpty()) text = "Tap to open Jarvis.";
                action = new Notification.Action.Builder(null, "Mark done",
                        broadcast(c, ITEM_DONE, code + 500000, id, code)).build();
                break;
            }
            default:
                return;
        }

        Intent open = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("tab", kind);
        PendingIntent openPi = PendingIntent.getActivity(c, code + 700000, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Scheduler.ensureChannel(c);
        Notification.Builder nb = new Notification.Builder(c, Scheduler.CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setColor(0xFF7CC4AA)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(openPi)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER);
        if (action != null) nb.addAction(action);
        nm.notify(code, nb.build());
    }
}
