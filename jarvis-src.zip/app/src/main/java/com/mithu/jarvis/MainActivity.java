package com.mithu.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

/** The screens are a web page inside the app; this class connects them to Android's reminders. */
public class MainActivity extends Activity {

    private WebView web;
    private String startTab = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#CBEBDF"));
        getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
        getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        Scheduler.ensureChannel(this);

        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        readTab(getIntent());
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        Scheduler.scheduleAll(this);
    }

    private void readTab(Intent i) {
        String k = i == null ? null : i.getStringExtra("tab");
        if (k == null) { startTab = ""; return; }
        switch (k) {
            case "kitchen": case "cook": case "grocery": case "alarm": startTab = "kitchen"; break;
            case "task": case "focus": case "weekly": startTab = "plan"; break;
            case "weigh": startTab = "me"; break;
            default: startTab = "today";
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        readTab(intent);
        if (!startTab.isEmpty()) web.evaluateJavascript("window.openTab&&openTab('" + startTab + "')", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Scheduler.scheduleAll(this);
        if (web != null) web.evaluateJavascript("window.appResume&&appResume()", null);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.appBack?appBack():false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    class Bridge {
        @JavascriptInterface
        public String load() {
            return getSharedPreferences(Scheduler.PREFS, 0).getString("state", "");
        }

        @JavascriptInterface
        public void save(String json) {
            try {
                new JSONObject(json); // only save valid data
                getSharedPreferences(Scheduler.PREFS, 0).edit().putString("state", json).commit();
                Scheduler.scheduleAll(MainActivity.this);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String startTab() {
            String t = startTab;
            startTab = "";
            return t;
        }

        @JavascriptInterface
        public boolean exactOk() {
            return Scheduler.exactAllowed(MainActivity.this);
        }

        @JavascriptInterface
        public void askExact() {
            if (Build.VERSION.SDK_INT >= 31) runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    toast("Open Settings > Apps > Jarvis > Alarms & reminders");
                }
            });
        }

        @JavascriptInterface
        public boolean notifOk() {
            if (Build.VERSION.SDK_INT < 33) return true;
            return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void askNotif() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                } else {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(i);
                }
            });
        }

        @JavascriptInterface
        public void openBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void toast(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
