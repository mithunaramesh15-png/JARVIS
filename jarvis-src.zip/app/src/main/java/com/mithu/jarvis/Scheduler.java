package com.mithu.jarvis;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Reads the saved app data and sets the next time for every reminder. */
public class Scheduler {

    static final String PREFS = "jarvis";
    static final String CHANNEL = "reminders";

    static final int WATER = 1, SLEEP = 2, KITCHEN = 3, COOK = 4, WEIGH = 5, FOCUS = 6,
            NUTS = 7, NUTSOAK = 8, GROCERY = 9, WEEKLY = 10;

    // ---------- saved data ----------

    static JSONObject state(Context c) {
        try {
            String s = c.getSharedPreferences(PREFS, 0).getString("state", "");
            return s.isEmpty() ? new JSONObject() : new JSONObject(s);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static void saveState(Context c, JSONObject s) {
        c.getSharedPreferences(PREFS, 0).edit().putString("state", s.toString()).commit();
    }

    static String day(long ms) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(ms));
    }

    static String today() {
        return day(System.currentTimeMillis());
    }

    static JSONObject settings(JSONObject s, String key) {
        JSONObject set = s.optJSONObject("settings");
        if (set == null) return new JSONObject();
        JSONObject o = set.optJSONObject(key);
        return o == null ? new JSONObject() : o;
    }

    static int minutes(String hhmm, int def) {
        try {
            String[] p = hhmm.split(":");
            return Integer.parseInt(p[0].trim()) * 60 + Integer.parseInt(p[1].trim());
        } catch (Exception e) {
            return def;
        }
    }

    static String hhmm(int m) {
        m = ((m % 1440) + 1440) % 1440;
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60);
    }

    // ---------- next times ----------

    static Calendar todayAt(int m) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.MINUTE, m);
        return c;
    }

    static long nextDaily(int m) {
        Calendar c = todayAt(m);
        if (c.getTimeInMillis() <= System.currentTimeMillis() + 5000) c.add(Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    static long nextWater(int start, int end, int every) {
        if (every < 15) every = 15;
        long now = System.currentTimeMillis() + 5000;
        for (int t = start; t <= end; t += every) {
            long at = todayAt(t).getTimeInMillis();
            if (at > now) return at;
        }
        Calendar c = todayAt(start);
        c.add(Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    /** dow: 0 = Sunday ... 6 = Saturday */
    static long nextWeekly(int dow, int m) {
        Calendar c = todayAt(m);
        int cur = c.get(Calendar.DAY_OF_WEEK) - 1;
        c.add(Calendar.DAY_OF_YEAR, ((dow - cur) % 7 + 7) % 7);
        if (c.getTimeInMillis() <= System.currentTimeMillis() + 5000) c.add(Calendar.DAY_OF_YEAR, 7);
        return c.getTimeInMillis();
    }

    // ---------- alarm plumbing ----------

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Water, sleep, food, cooking and task reminders");
                ch.enableVibration(true);
                nm.createNotificationChannel(ch);
            }
        }
    }

    static PendingIntent alarmIntent(Context c, int code, String kind, String taskId) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("com.mithu.jarvis.ALARM_" + code);
        i.putExtra("kind", kind);
        i.putExtra("code", code);
        if (taskId != null) i.putExtra("task", taskId);
        return PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static boolean exactAllowed(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = c.getSystemService(AlarmManager.class);
        return am.canScheduleExactAlarms();
    }

    static void set(Context c, int code, String kind, long when, String taskId) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent p = alarmIntent(c, code, kind, taskId);
        if (when <= 0) {
            am.cancel(p);
            return;
        }
        try {
            if (exactAllowed(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
        }
    }

    static int taskCode(String id) {
        return 1000 + Math.abs(id.hashCode() % 900000);
    }

    // ---------- main ----------

    static synchronized void scheduleAll(Context c) {
        ensureChannel(c);
        JSONObject s = state(c);

        JSONObject w = settings(s, "water");
        set(c, WATER, "water", w.optBoolean("on", true)
                ? nextWater(minutes(w.optString("start", "08:00"), 480),
                            minutes(w.optString("end", "21:30"), 1290),
                            w.optInt("every", 90))
                : -1, null);

        JSONObject sl = settings(s, "sleep");
        set(c, SLEEP, "sleep", sl.optBoolean("on", true)
                ? nextDaily(((minutes(sl.optString("bed", "22:30"), 1350) - sl.optInt("lead", 30)) % 1440 + 1440) % 1440)
                : -1, null);

        JSONObject k = settings(s, "kitchen");
        set(c, KITCHEN, "kitchen", k.optBoolean("on", true)
                ? nextDaily(minutes(k.optString("time", "09:00"), 540)) : -1, null);

        JSONObject ck = settings(s, "cook");
        set(c, COOK, "cook", ck.optBoolean("on", true)
                ? nextDaily(minutes(ck.optString("time", "18:00"), 1080)) : -1, null);

        JSONObject wg = settings(s, "weigh");
        set(c, WEIGH, "weigh", wg.optBoolean("on", true)
                ? nextWeekly(wg.optInt("day", 0), minutes(wg.optString("time", "07:00"), 420)) : -1, null);

        JSONObject n = settings(s, "nuts");
        set(c, NUTS, "nuts", n.optBoolean("on", true)
                ? nextDaily(minutes(n.optString("time", "10:30"), 630)) : -1, null);
        set(c, NUTSOAK, "nutsoak", n.optBoolean("on", true) && n.optBoolean("soak", true)
                ? nextDaily(minutes(n.optString("soakTime", "21:30"), 1290)) : -1, null);

        JSONObject g = settings(s, "grocery");
        set(c, GROCERY, "grocery", g.optBoolean("on", true)
                ? nextWeekly(g.optInt("day", 6), minutes(g.optString("time", "10:00"), 600)) : -1, null);

        JSONObject wk = settings(s, "weekly");
        set(c, WEEKLY, "weekly", wk.optBoolean("on", true)
                ? nextWeekly(wk.optInt("day", 5), minutes(wk.optString("time", "19:00"), 1140)) : -1, null);

        // One-time reminders (tasks + soak/prep steps): cancel the old ones, then set the waiting ones.
        SharedPreferences p = c.getSharedPreferences(PREFS, 0);
        for (String code : p.getString("oneCodes", "").split(",")) {
            if (!code.isEmpty()) {
                try { set(c, Integer.parseInt(code), "task", -1, null); } catch (Exception ignored) { }
            }
        }
        List<String> codes = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (String listName : new String[]{"tasks", "alarms"}) {
            JSONArray arr = s.optJSONArray(listName);
            if (arr == null) continue;
            String kind = listName.equals("tasks") ? "task" : "alarm";
            for (int i = 0; i < arr.length(); i++) {
                JSONObject t = arr.optJSONObject(i);
                if (t == null || t.optBoolean("done")) continue;
                long due = t.optLong("due", 0);
                String id = t.optString("id", "");
                if (due > now && !id.isEmpty()) {
                    int code = taskCode(id);
                    set(c, code, kind, due, id);
                    codes.add(String.valueOf(code));
                }
            }
        }
        p.edit().putString("oneCodes", String.join(",", codes)).apply();

        // Focus timer
        long focusEnd = s.optLong("focusEnd", 0);
        set(c, FOCUS, "focus", focusEnd > now ? focusEnd : -1, null);
    }

    // ---------- helpers used by notifications ----------

    static double latestWeight(JSONObject s) {
        JSONArray ws = s.optJSONArray("weights");
        if (ws == null || ws.length() == 0) return 0;
        String best = "";
        double kg = 0;
        for (int i = 0; i < ws.length(); i++) {
            JSONObject o = ws.optJSONObject(i);
            if (o != null && o.optString("d").compareTo(best) >= 0) {
                best = o.optString("d");
                kg = o.optDouble("kg", 0);
            }
        }
        return kg;
    }

    static double proteinToday(JSONObject s) {
        JSONObject food = s.optJSONObject("food");
        if (food == null) return 0;
        JSONArray arr = food.optJSONArray(today());
        double sum = 0;
        if (arr != null) for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null) sum += o.optDouble("p", 0);
        }
        return sum;
    }

    /** Items that expire within 2 days (or already expired), soonest first, as "Name (when)". */
    static List<String> expiringSoon(JSONObject s) {
        List<String> out = new ArrayList<>();
        List<Long> days = new ArrayList<>();
        JSONArray items = s.optJSONArray("kitchen");
        if (items == null) return out;
        long start = todayAt(0).getTimeInMillis();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            String exp = o.optString("exp", "");
            if (exp.isEmpty()) continue;
            try {
                long d = Math.round((f.parse(exp).getTime() - start) / 86400000.0);
                if (d <= 2) {
                    String when = d < 0 ? "expired" : d == 0 ? "today" : d == 1 ? "tomorrow" : "in 2 days";
                    int pos = 0;
                    while (pos < days.size() && days.get(pos) <= d) pos++;
                    days.add(pos, d);
                    out.add(pos, o.optString("name", "item") + " (" + when + ")");
                }
            } catch (Exception ignored) { }
        }
        return out;
    }

    static String mondayKey() {
        Calendar c = todayAt(0);
        int dow = c.get(Calendar.DAY_OF_WEEK); // Sun=1
        c.add(Calendar.DAY_OF_YEAR, -((dow + 5) % 7));
        return day(c.getTimeInMillis());
    }

    static int daysLeftInWeek() {
        int dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
        return dow == Calendar.SUNDAY ? 1 : 9 - dow; // including today
    }

    /** Weekly tasks not finished this week. */
    static List<String> weeklyPending(JSONObject s) {
        List<String> out = new ArrayList<>();
        JSONArray arr = s.optJSONArray("weekly");
        if (arr == null) return out;
        String wk = mondayKey();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            boolean repeat = o.optBoolean("repeat");
            String week = o.optString("week", "");
            int target = Math.max(1, o.optInt("target", 1));
            JSONObject log = o.optJSONObject("log");
            if (repeat || week.equals(wk)) {
                int doneN = log == null ? 0 : log.optInt(wk, 0);
                if (doneN < target) out.add(o.optString("t") + (target > 1 ? " (" + doneN + "/" + target + ")" : ""));
            } else if (week.compareTo(wk) < 0) {
                int doneN = log == null ? 0 : log.optInt(week, 0);
                if (doneN < target) out.add(o.optString("t"));
            }
        }
        return out;
    }

    static List<String> groceryList(JSONObject s) {
        List<String> out = new ArrayList<>();
        JSONArray arr = s.optJSONArray("grocery");
        if (arr != null) for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && !o.optBoolean("done")) out.add(o.optString("name"));
        }
        return out;
    }
}
