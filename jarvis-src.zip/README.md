# Jarvis
Personal app: calories & protein, PCOD-friendly recipes (instant / soaking), kitchen expiry tracker, soak / sprout / instant-mix reminders, grocery list, weekly tasks, water, sleep and nuts reminders, focus timer.

Download: open **Releases** and get `Jarvis.apk`.
